#include <stdio.h>

int main(){
  int a = atoi(argv[0]);
  int b = atoi(argv[1]);

  printf("La somme de %d et %d vaut %d\n", a, b, a+b);
  
}